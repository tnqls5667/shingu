a = "Gachon"
b = "University"
a+""+b
'Cachon University'
a*2+" "+b*2
'GachonGachon UniversityUniversity'
if 'U' in a: print a
else: print b
